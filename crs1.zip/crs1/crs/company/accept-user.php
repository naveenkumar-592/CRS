<?php
session_start();
require_once("../db.php");
$sql = "UPDATE apply_job_post SET status='2' WHERE id_jobpost='$_GET[id_jobpost]' AND id_user='$_GET[id_user]'";
if($conn->query($sql) === TRUE) {
	
	$id=$_GET[id_user];
	$result = mysqli_query($conn, "SELECT * FROM users WHERE id_user='$id' ") or die('Error');
    while ($row = mysqli_fetch_array($result)) {
        #$username = $row['username'];
		$email=$row['email'];
    }
 
	$to=$email;
	$id1=$_GET['id_jobpost'];
	$result = mysqli_query($conn, "SELECT * FROM apply_job_post WHERE id_jobpost='$id1' ") or die('Error');
    
	while ($row = mysqli_fetch_array($result)) {
        $id2 = $row['id_company'];
		$result = mysqli_query($conn, "SELECT * company where id_company='$id2' ") or die('Error');
		while ($row = mysqli_fetch_array($result)) {
        #$username = $row['username'];
			$from=$row['email'];
    }
		
    }
	if(mail($to,'Accepted-system generated mail','you have been selected for round two.',$from)){
	  #echo " successful";
	  echo "<script>window.open('successful')</script>";
  }
  else{
	  #echo "failed";
	  echo "<script>window.open('failed')</script>";
  }
	header("Location: view-job-application.php");
	exit();
} else {
	echo "Error!";
}
$conn->close();
?>