<?php
session_start();
require_once("../db.php");
$sql = "UPDATE apply_intern_post SET status='1' WHERE id_internpost='$_GET[id_internpost]' AND id_user='$_GET[id_user]'";
if($conn->query($sql) === TRUE) {
	header("Location: view-intern-application.php");
	exit();
} else {
	echo "Error!";
}
$conn->close();
?>