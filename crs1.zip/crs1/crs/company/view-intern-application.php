<?php
//To Handle Session Variables on This Page
session_start();
//If user Not logged in then redirect them back to homepage. 
//This is required if user tries to manually enter dashboard.php in URL.
if(empty($_SESSION['id_user'])) {
  header("Location: ../index.php");
  exit();
}
require_once("../db.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Application Details</title>

    <link rel="icon" href="../img/favicon.png" type="image/x-icon"/>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    
    <!-- NAVIGATION BAR -->
   <font face="calibri">
    
    <!-- NAVIGATION BAR -->
    <section>
    <div class="container">
      <div class="row">
        <header>
          <nav class="navbar navbar-default" style="margin-bottom: 0; height: 80px; background-color: white; border-color: transparent;">
            <div class="container-fluid">

              <div class="navbar-header">
                <a class="navbar-brand" style="font-size: 24px; color: #053a5a; line-height: 42px;" href="../index.php">Way To Life</a>
              </div>

              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1"> 
                <ul class="nav navbar-nav navbar-right">
                  <li style="padding-right: 25px;"><a href="dashboard.php" style="font-size: 24px; color: #053a5a; line-height: 42px;">Dashboard</a></li>
                  <li style="padding-right: 25px;"><a href="../logout.php" style="font-size: 24px; color: #053a5a; line-height: 42px;">Logout</a></li>
                </ul>
              </div>

            </div>

          </nav>
        </header>
      </div>
    </div>
  </section>

  <div style="background-color: #053a5a; height: 80px;">
    <p style="font-size: 34px; color: white; text-align: center; line-height: 75px;">Application Details</p>
  </div>

  <br>
  <br>

    <div class="container">
      <div class="row" align="center">
        <table style="width: 100%;">
          <thead>
            <th style="font-size: 20px; color: #053a5a">Job Post Name</th>
            <th style="font-size: 20px; color: #053a5a">Job Description</th>
            <th style="font-size: 20px; color: #053a5a">User Name</th>
            <th style="font-size: 20px; color: #053a5a">Action</th>
          </thead>
                        <tr>
                <td colspan="8"><hr style="border-color: black;"></td>
              </tr>
          <tbody>
            <?php
              $sql ="SELECT * FROM apply_intern_post INNER JOIN intern_post ON apply_intern_post.id_internpost=intern_post.id_internpost INNER JOIN users ON apply_intern_post.id_user=users.id_user WHERE apply_intern_post.id_company='$_SESSION[id_user]' AND apply_intern_post.status='0'";
              $result=$conn->query($sql);
              if($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                  ?>
                    <tr>
                      <td style="font-size: 20px;"><?php echo $row['interntitle']; ?></td>
                      <td style="font-size: 20px;"><?php echo $row['description']; ?></td>
                      <td style="font-size: 20px;"><?php echo $row['firstname'] . " " . $row['lastname']; ?></td>
                      <td style="font-size: 20px;"><a href="view-application1.php?id_user=<?php echo $row['id_user']; ?>&id_internpost=<?php echo $row['id_internpost']; ?>">View</a></td>
                    </tr>
                  <?php
                }
               }
            ?>
          </tbody>
        </table>
      </div>
    </div>

    <br><br>

        

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

     <script type="text/javascript">
      $(function() {
        $(".successMessage:visible").fadeOut(2000);
      });
    </script>
  </body>
</html>