<?php

session_start();

unset($_SESSION['uid']);
unset($_SESSION['key']);
unset($_SESSION['name']);
unset($_SESSION['username']);
header("location:index.php");
?>