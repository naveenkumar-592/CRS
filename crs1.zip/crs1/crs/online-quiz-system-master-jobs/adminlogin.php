<html>
<body>     

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header text-center" style="color:#fff;border-bottom: none;">
                          Exam  Paper Mangament
                        </h1>
                       
                    </div>
                </div>
                <!-- /.row -->

				
			
               
                <!-- /.row -->

                <div class="row">
				  <div class=" col-md-3">
				  &nbsp;
				  </div>
                    <div class=" col-md-6">
					
					
					
					
					 <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title"> Login(admin)</h3>
                            </div>
                            <div class="panel-body">
							
							
                         <form role="form" method="post" action="adminlogin.php" >

                            <div class="form-group">
                                <label>Username </label>
                                <input class="form-control" name="username" >
                               
                            </div>
							
							<div class="form-group">
                                <label>Password </label>
                                <input class="form-control"  type="password" name="password" >
                               
                            </div>
                         
                           
                            <button type="submit" name="login" class="btn btn-primary">Login </button>
							<br>
							<!--<a href="index1.php">Login(student)</a>-->

                        </form>
						</div>
                        </div>

                    </div>
					
					 <div class=" col-md-3">
				  &nbsp;
				  </div>
                   
                </div>
                <!-- /.row -->
           
               

            </div>
            <!-- /.container-fluid -->

   

</body>
</html>
<?php
$con= new mysqli('localhost:3308','root','','mini')or die("Could not connect to mysql".mysqli_error($con));
#$ref      = @$_GET['q'];
$username = $_POST['username'];
$password = $_POST['password'];
$result = mysqli_query($con, "SELECT username FROM admin1 WHERE username = '$username' and password = '$password'") or die('Error');
$count = mysqli_num_rows($result);
if ($count == 1) {
    session_start();
    if (isset($_SESSION['username'])) {
        session_unset();
    }
    $_SESSION["name"]     = 'Admin';
    $_SESSION["key"]      = '54585c506829293a2d4c3b68543b316e2e7a2d277858545a36362e5f39';
    $_SESSION["username"] = $username;
    header("location:dash.php?q=0");
} 
?>