<?php
session_start();
if (isset($_SESSION["username"])) {
    session_destroy();
}
include_once 'dbConnection.php';
#$ref      = @$_GET['q'];
$username = $_POST['username'];
$password = $_POST['password'];

$username = stripslashes($username);
$username = addslashes($username);
$password = stripslashes($password);
$password = addslashes($password);
$password = md5($password);
$result = mysqli_query($con, "SELECT username FROM user WHERE username = '$username' and password = '$password'") or die('Error');
$count = mysqli_num_rows($result);
if ($count == 1) {
    while ($row = mysqli_fetch_array($result)) {
        $username = $row['username'];
    }
    $_SESSION["name"]     = $username;
    $_SESSION["username"] = $username;
   header("location:account.php?q=1");
} else
{
	$q3 = mysqli_query($con, "INSERT INTO user VALUES  (NULL,'$username' , '$password')");
	$_SESSION["name"]     = $username;
       $_SESSION["username"] = $username;
    #$_SESSION["name"]     = $name;
    
    header("location:account.php?q=1");



#    header("location:$ref?w=Wrong Username or Password");
}

?>