<?php
	$con= new mysqli('localhost:3308','root','','quizi')or die("Could not connect to mysql".mysqli_error($con));
?>