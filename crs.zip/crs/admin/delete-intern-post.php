<?php
session_start();
if(empty($_SESSION['id_admin'])) {
	header("Location: index.php");
	exit();
}
require_once("../db.php");
if(isset($_GET)) {
	$sql = "DELETE FROM intern_post WHERE id_internpost='$_GET[id]'";
	if($conn->query($sql)) {
		$sql1 = "DELETE FROM apply_intern_post WHERE id_internpost='$_GET[id]'";
		if($conn->query($sql1)) {
		}
		header("Location: internship-posts.php");
		exit();
	} else {
		echo "Error";
	}
}