<?php
session_start();

include_once 'dbConnection.php';
#$ref      = @$_GET['q'];
$username = $_POST['username'];
$password = $_POST['password'];

$username = stripslashes($username);
$username = addslashes($username);
$password = stripslashes($password);
$password = addslashes($password);
$password = md5($password);
$result = mysqli_query($con, "SELECT username FROM admin WHERE username = '$username' and password = '$password'") or die('Error');
$count = mysqli_num_rows($result);
if ($count == 1) {
    while ($row = mysqli_fetch_array($result)) {
		$_SESSION["name"]     = 'Admin';
    $_SESSION["key"]      = '54585c506829293a2d4c3b68543b316e2e7a2d277858545a36362e5f39';
        $username = $row['username'];
    }
    #$_SESSION["name"]     = $name;
    $_SESSION["username"] = $username;
   header("location:dash.php?q=0");
} else
{
	$q3 = mysqli_query($con, "INSERT INTO admin VALUES  (NULL,'$username' , '$password')");
	$_SESSION["name"]     = 'Admin';
    $_SESSION["key"]      = '54585c506829293a2d4c3b68543b316e2e7a2d277858545a36362e5f39';
       $_SESSION["username"] = $username;
    #$_SESSION["name"]     = $name;
    
    header("location:dash.php?q=0");



#    header("location:$ref?w=Wrong Username or Password");
}

?>